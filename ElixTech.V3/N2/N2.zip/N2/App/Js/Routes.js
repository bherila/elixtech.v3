﻿(function (module) {
})(angular.module('n2.routes', []));